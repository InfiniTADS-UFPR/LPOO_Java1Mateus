/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lista_6;

/**
 *
 * @author mateus
 */
public class C {
    public String attibuto1;
    public float atributo2;
    
    C(){
        this.attibuto1 = "VAZIO";
        this.atributo2 = -999.99f;
    }
    
    C(String p1, float p2){
        this.attibuto1 = p1;
        this.atributo2 = p2;
    }
}
